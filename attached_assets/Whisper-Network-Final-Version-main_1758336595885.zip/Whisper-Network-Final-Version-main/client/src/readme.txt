public release 0.9.8, working functionally for wide internet distribution 
